# Basehit.io - Rebranded Files
Generated: December 27, 2025

## Overview
Clean, rebranded PHP files for Basehit.io platform.
All "Lustifieds" references updated to "Basehit"
All domains updated to basehit.io

## Branding
- Site Name: Basehit
- Domain: basehit.io
- Emails: *@basehit.io

## Files Included (33 total)

### Core Pages
- index.php - Homepage
- footer.php - Site footer
- contact.php - Contact page
- blog.php - Blog

### User Management
- register.php - User registration
- login.php - User login
- profile.php - User profile
- edit-profile.php - Edit profile
- membership.php - Membership/Premium

### Browse & Listings
- browse.php - Browse all listings
- city.php - City listings
- listing.php - Single listing view
- create-listing.php - Create listing
- edit-listing.php - Edit listing
- post-ad.php - Post advertisement
- become-creator.php - Creator signup
- announcements.php - Announcements

### Creator Dashboard
- creator-dashboard.php - Dashboard
- creator-analytics.php - Analytics
- creator-earnings.php - Earnings
- creator-listings.php - Manage listings
- creator-upload.php - Upload content
- creator-edit-listing.php - Edit listing
- creator-settings.php - Settings

### Marketplace
- marketplace.php - Marketplace
- marketlisting.php - Listing view

### Stories
- story.php - Stories listing
- story-view.php - View story
- story-submit.php - Submit story

### Forum & Support
- forum.php - Forum
- forum-search.php - Search
- faq.php - FAQ
- feedback.php - Feedback

## Installation
1. Extract to web root
2. Configure database settings
3. Ensure proper permissions
4. Test functionality

## Additional Pages
These were created separately and should be added:
- about.php - About Basehit
- terms.php - Terms of Service
- privacy.php - Privacy Policy
- safety.php - Safety Tips
- guidelines.php - Community Guidelines
- report.php - Report Abuse

Support: support@basehit.io
