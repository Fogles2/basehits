<?php
session_start();
require_once 'config/database.php';

// Redirect if already logged in
if(isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

$error = '';
$success = '';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $agree_terms = isset($_POST['agree_terms']);
    
    // Validation
    if(empty($username) || empty($email) || empty($password)) {
        $error = 'All fields are required';
    } elseif(strlen($username) < 3) {
        $error = 'Username must be at least 3 characters';
    } elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Invalid email address';
    } elseif(strlen($password) < 6) {
        $error = 'Password must be at least 6 characters';
    } elseif($password !== $confirm_password) {
        $error = 'Passwords do not match';
    } elseif(!$agree_terms) {
        $error = 'You must agree to the Terms of Service';
    } else {
        // Check if username or email already exists
        $check = $db->prepare("SELECT id FROM users WHERE username = :username OR email = :email");
        $check->execute([':username' => $username, ':email' => $email]);
        
        if($check->fetch()) {
            $error = 'Username or email already exists';
        } else {
            // Create user
            try {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $verification_token = bin2hex(random_bytes(32));
                
                $query = "INSERT INTO users (username, email, password, verification_token, created_at) 
                          VALUES (:username, :email, :password, :verification_token, NOW())";
                
                $stmt = $db->prepare($query);
                $stmt->execute([
                    ':username' => $username,
                    ':email' => $email,
                    ':password' => $hashed_password,
                    ':verification_token' => $verification_token
                ]);
                
                // Send verification email (implement later)
                // mail($email, 'Verify Your Email', 'Click here to verify: ...');
                
                $success = 'Account created successfully! You can now log in.';
                
                // Optional: Auto-login after registration
                // $_SESSION['user_id'] = $db->lastInsertId();
                // header('Location: dashboard.php');
                // exit();
            } catch(PDOException $e) {
                $error = 'Registration failed. Please try again.';
                error_log('Registration error: ' . $e->getMessage());
            }
        }
    }
}

include 'views/header.php';
?>

<!-- Hero Section -->
<div class="relative overflow-hidden bg-gradient-to-br from-purple-900 via-pink-900 to-red-900 py-12">
    <div class="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PHBhdGggZD0iTTM2IDEzNGg3djdjMCAxLjEwNS0uODk1IDItMiAyaC0zYy0xLjEwNSAwLTItLjg5NS0yLTJ2LTd6bTAtMTRoN3Y3YzAgMS4xMDUtLjg5NSAyLTIgMmgtM2MtMS4xMDUgMC0yLS44OTUtMi0ydi03eiIvPjwvZz48L2c+PC9zdmc+')] opacity-10"></div>
    
    <div class="relative mx-auto max-w-6xl px-4 text-center">
        <div class="mb-4 inline-flex h-14 w-14 items-center justify-center rounded-full bg-white/10 text-3xl backdrop-blur-sm">
            <i class="bi bi-person-plus-fill text-pink-300"></i>
        </div>
        <h1 class="mb-3 bg-gradient-to-r from-white via-pink-200 to-white bg-clip-text text-4xl font-bold text-transparent md:text-5xl">
            Join Lustifieds
        </h1>
        <p class="text-base text-pink-200">Create your free account and start connecting today!</p>
    </div>
</div>

<!-- Main Content -->
<div class="bg-gh-bg py-12">
    <div class="mx-auto max-w-md px-4">

        <?php if($success): ?>
        <div class="mb-6 flex items-start gap-3 rounded-lg border border-green-500/30 bg-green-500/10 p-4">
            <i class="bi bi-check-circle-fill mt-0.5 text-green-500"></i>
            <div>
                <p class="font-semibold text-green-400">Success!</p>
                <p class="text-sm text-green-300"><?php echo htmlspecialchars($success); ?></p>
                <a href="login.php" class="mt-2 inline-flex items-center gap-1 text-sm font-semibold text-green-400 hover:text-green-300">
                    Login now <i class="bi bi-arrow-right"></i>
                </a>
            </div>
        </div>
        <?php endif; ?>

        <?php if($error): ?>
        <div class="mb-6 flex items-start gap-3 rounded-lg border border-red-500/30 bg-red-500/10 p-4">
            <i class="bi bi-exclamation-circle-fill mt-0.5 text-red-500"></i>
            <div>
                <p class="font-semibold text-red-400">Error</p>
                <p class="text-sm text-red-300"><?php echo htmlspecialchars($error); ?></p>
            </div>
        </div>
        <?php endif; ?>

        <!-- Register Form -->
        <div class="rounded-lg border border-gh-border bg-gh-panel p-8">
            <h2 class="mb-6 text-center text-2xl font-bold text-white">Create Account</h2>

            <form method="POST" class="space-y-4">
                
                <!-- Username -->
                <div>
                    <label class="mb-2 block text-sm font-semibold text-white">
                        <i class="bi bi-person-fill mr-1 text-gh-accent"></i>
                        Username
                    </label>
                    <input 
                        type="text" 
                        name="username" 
                        required
                        minlength="3"
                        maxlength="50"
                        value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>"
                        class="w-full rounded-lg border border-gh-border bg-gh-bg px-4 py-3 text-white transition-colors focus:border-gh-accent focus:outline-none focus:ring-2 focus:ring-gh-accent/20"
                        placeholder="Choose a unique username"
                    >
                    <p class="mt-1 text-xs text-gh-muted">This will be your public display name</p>
                </div>

                <!-- Email -->
                <div>
                    <label class="mb-2 block text-sm font-semibold text-white">
                        <i class="bi bi-envelope-fill mr-1 text-gh-accent"></i>
                        Email Address
                    </label>
                    <input 
                        type="email" 
                        name="email" 
                        required
                        value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>"
                        class="w-full rounded-lg border border-gh-border bg-gh-bg px-4 py-3 text-white transition-colors focus:border-gh-accent focus:outline-none focus:ring-2 focus:ring-gh-accent/20"
                        placeholder="your@email.com"
                    >
                    <p class="mt-1 text-xs text-gh-muted">We'll never share your email</p>
                </div>

                <!-- Password -->
                <div>
                    <label class="mb-2 block text-sm font-semibold text-white">
                        <i class="bi bi-lock-fill mr-1 text-gh-accent"></i>
                        Password
                    </label>
                    <div class="relative">
                        <input 
                            type="password" 
                            name="password" 
                            id="password"
                            required
                            minlength="6"
                            class="w-full rounded-lg border border-gh-border bg-gh-bg px-4 py-3 pr-12 text-white transition-colors focus:border-gh-accent focus:outline-none focus:ring-2 focus:ring-gh-accent/20"
                            placeholder="Minimum 6 characters"
                        >
                        <button 
                            type="button" 
                            onclick="togglePassword('password')"
                            class="absolute right-3 top-1/2 -translate-y-1/2 text-gh-muted hover:text-white"
                        >
                            <i class="bi bi-eye-fill" id="password-icon"></i>
                        </button>
                    </div>
                </div>

                <!-- Confirm Password -->
                <div>
                    <label class="mb-2 block text-sm font-semibold text-white">
                        <i class="bi bi-lock-fill mr-1 text-gh-accent"></i>
                        Confirm Password
                    </label>
                    <div class="relative">
                        <input 
                            type="password" 
                            name="confirm_password" 
                            id="confirm_password"
                            required
                            minlength="6"
                            class="w-full rounded-lg border border-gh-border bg-gh-bg px-4 py-3 pr-12 text-white transition-colors focus:border-gh-accent focus:outline-none focus:ring-2 focus:ring-gh-accent/20"
                            placeholder="Re-enter your password"
                        >
                        <button 
                            type="button" 
                            onclick="togglePassword('confirm_password')"
                            class="absolute right-3 top-1/2 -translate-y-1/2 text-gh-muted hover:text-white"
                        >
                            <i class="bi bi-eye-fill" id="confirm_password-icon"></i>
                        </button>
                    </div>
                </div>

                <!-- Terms Agreement -->
                <div class="flex items-start gap-3 rounded-lg border border-gh-border bg-gh-bg p-4">
                    <input 
                        type="checkbox" 
                        name="agree_terms" 
                        id="agree_terms"
                        required
                        class="mt-1 h-4 w-4 rounded border-gh-border bg-gh-panel text-gh-accent focus:ring-2 focus:ring-gh-accent/20"
                    >
                    <label for="agree_terms" class="text-sm text-gh-muted">
                        I agree to the <a href="terms.php" class="text-gh-accent hover:underline">Terms of Service</a> and <a href="privacy.php" class="text-gh-accent hover:underline">Privacy Policy</a>. I am at least 18 years old.
                    </label>
                </div>

                <!-- Submit Button -->
                <button 
                    type="submit"
                    class="group flex w-full items-center justify-center gap-2 rounded-lg bg-gradient-to-r from-pink-600 to-purple-600 px-6 py-3 font-bold text-white shadow-lg transition-all hover:brightness-110"
                >
                    <i class="bi bi-person-plus-fill"></i>
                    Create Account
                    <i class="bi bi-arrow-right transition-transform group-hover:translate-x-1"></i>
                </button>
            </form>

            <!-- Divider -->
            <div class="my-6 flex items-center gap-3">
                <div class="h-px flex-1 bg-gh-border"></div>
                <span class="text-xs text-gh-muted">OR</span>
                <div class="h-px flex-1 bg-gh-border"></div>
            </div>

            <!-- Social Login Buttons -->
            <div class="space-y-3">
                <button class="flex w-full items-center justify-center gap-3 rounded-lg border border-gh-border bg-gh-bg px-6 py-3 font-semibold text-white transition-all hover:border-gh-accent">
                    <i class="bi bi-google text-xl"></i>
                    Continue with Google
                </button>
                <button class="flex w-full items-center justify-center gap-3 rounded-lg border border-gh-border bg-gh-bg px-6 py-3 font-semibold text-white transition-all hover:border-gh-accent">
                    <i class="bi bi-facebook text-xl"></i>
                    Continue with Facebook
                </button>
            </div>

            <!-- Login Link -->
            <div class="mt-6 text-center">
                <p class="text-sm text-gh-muted">
                    Already have an account? 
                    <a href="login.php" class="font-semibold text-gh-accent hover:text-gh-success">
                        Login here
                    </a>
                </p>
            </div>
        </div>

        <!-- Benefits Section -->
        <div class="mt-8 rounded-lg border border-gh-border bg-gh-panel p-6">
            <h3 class="mb-4 text-center text-lg font-bold text-white">Why Join Lustifieds?</h3>
            <div class="space-y-3">
                <div class="flex items-start gap-3">
                    <div class="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-pink-500 to-purple-600 text-white">
                        <i class="bi bi-check-lg"></i>
                    </div>
                    <div>
                        <div class="font-semibold text-white">100% Free to Join</div>
                        <div class="text-xs text-gh-muted">No credit card required</div>
                    </div>
                </div>
                <div class="flex items-start gap-3">
                    <div class="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-pink-500 to-purple-600 text-white">
                        <i class="bi bi-check-lg"></i>
                    </div>
                    <div>
                        <div class="font-semibold text-white">Safe & Secure</div>
                        <div class="text-xs text-gh-muted">Your privacy is protected</div>
                    </div>
                </div>
                <div class="flex items-start gap-3">
                    <div class="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-pink-500 to-purple-600 text-white">
                        <i class="bi bi-check-lg"></i>
                    </div>
                    <div>
                        <div class="font-semibold text-white">Connect Locally</div>
                        <div class="text-xs text-gh-muted">Find people near you</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function togglePassword(fieldId) {
    const field = document.getElementById(fieldId);
    const icon = document.getElementById(fieldId + '-icon');
    
    if(field.type === 'password') {
        field.type = 'text';
        icon.classList.remove('bi-eye-fill');
        icon.classList.add('bi-eye-slash-fill');
    } else {
        field.type = 'password';
        icon.classList.remove('bi-eye-slash-fill');
        icon.classList.add('bi-eye-fill');
    }
}
</script>

<?php include 'views/footer.php'; ?>
