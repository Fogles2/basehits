Please read the full licensing terms on the following link:

https://flowbite.com/license/