# Basehit.io - Rebranded Files
Date: December 27, 2025

## Changes Applied
✓ All "Lustifieds" references changed to "Basehit"
✓ All domains changed to basehit.io
✓ File names cleaned (version numbers removed)
✓ 25 total branding updates across files

## Branding
- Site Name: Basehit
- Domain: basehit.io
- Emails: *@basehit.io

## Files (33 PHP files)
index.php, footer.php, contact.php, blog.php,
register.php, login.php, profile.php, edit-profile.php,
membership.php, browse.php, city.php, listing.php,
create-listing.php, edit-listing.php, post-ad.php,
become-creator.php, announcements.php,
creator-dashboard.php, creator-analytics.php,
creator-earnings.php, creator-listings.php,
creator-upload.php, creator-edit-listing.php,
creator-settings.php, marketplace.php, marketlisting.php,
story.php, story-view.php, story-submit.php,
forum.php, forum-search.php, faq.php, feedback.php

## Installation
1. Extract all files
2. Upload to web root
3. Update config/database.php
4. Test functionality

## Requirements
- PHP 7.4+
- MySQL/MariaDB
- Tailwind CSS (gh- color variables)
- Bootstrap Icons
- views/header.php and views/footer.php

## Support
Email: support@basehit.io
Website: https://basehit.io
